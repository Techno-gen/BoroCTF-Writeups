#include <stdio.h>
#include <stdlib.h>

__attribute__((constructor)) void unbuffer() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}
