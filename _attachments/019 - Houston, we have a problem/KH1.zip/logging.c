#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fitsio.h>

#define FLAGSIZE 256
#define CARDSIZE 80

#define SUCCESS 1000
#define FAILURE 1001

void print_menu();
int print_logs();
int write_log();
int emergency_orbit_realignment(int distance);

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);

    int status = SUCCESS;
    printf("Welcome to the KH-1 satallite logging system!\n");
    printf("\033[0;31mMany functions have been deprecated and moved to other systems in the satallite.\033[0m\n");

    while (1) {
        print_menu();
        char buf[CARDSIZE + 1];
        fgets(buf, CARDSIZE + 1, stdin);

        buf[strcspn(buf, "\r\n")] = 0;

        if (strcmp(buf, "Print logs") == 0) {
            status = print_logs();
        }
        else if (strcmp(buf, "Write log") == 0) {
            status = write_log();
        }
        else if (strcmp(buf, "Exit safely") == 0) {
            exit(status);
        } else {
            printf("Unrecognized Command\n");
            continue;
        }

        if (status == FAILURE) {
            return status;
        }
    }
    return 0;
}

void print_menu() {
    printf("\nOptions:\n");
    printf("Print logs\n");
    printf("Write log\n");
    printf("Exit safely\n");
    printf("> ");
    return;
}

int print_logs() {
    fitsfile *fptr;
    int status = 0;

    if (fits_open_file(&fptr, "telemetry_log.fit", READWRITE, &status)) {
        return FAILURE;
    }

    int key_count;
    int space_leftover;
    char record[CARDSIZE];

    if (fits_get_hdrspace(fptr, &key_count, &space_leftover, &status)) {
            fits_close_file(fptr, &status);
            return FAILURE;
    }

    for (int i = 1; i <= key_count; i++) {
        if (fits_read_record(fptr, i, record, &status)) {
            break; 
        }
        printf("%s\n", record);
    }

    fits_close_file(fptr, &status);

    return SUCCESS;
}

int write_log() {
    char log[CARDSIZE*16 + 1];
    
    printf("Enter your new log:\n");
    printf("> ");
    if (!fgets(log, sizeof(log), stdin)) return FAILURE;
    log[strcspn(log, "\r\n")] = 0;

    if (strchr(log, ' ')) {
    return EXIT_FAILURE;
    }

    FILE *fptr = fopen("telemetry_log.fit", "r+");
    if (!fptr) {
        perror("fopen");
        return FAILURE;
    }

    fseek(fptr, 720, SEEK_SET);

    fprintf(fptr, log);
    fclose(fptr);

    return SUCCESS;
}

int emergency_orbit_realignment(int distance) {
    printf("\033[0;31mEmergency Detected!\033[0m\n");
    printf("Realigning to %d km from earth\n", distance);

    if (distance < 160) {
        printf("\033[0;31mFATAL ERROR: EXITING LOW EARTH ORBIT\033[0m\n");
        FILE *f = fopen("./flag.txt", "r");
        if (!f) {
            printf("Failed to open flag.txt\n");
            return EXIT_FAILURE;
        }
        char flag[FLAGSIZE];
        if (!fgets(flag, sizeof(flag), f)) {
            printf("Failed to read flag.txt\n");
            fclose(f);
            return EXIT_FAILURE;
        }
        fclose(f);
        printf("%s\n", flag);
    }
    else {
        printf("\n\033[0;32msuccessfully relocated to the safe distance of %d km.\033[0m\n", distance);
    }

    return SUCCESS;
}