#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define FLEET_SIZE 10
#define SHIP_SIZE 136
#define BUFFSIZE 64

char *fleet[FLEET_SIZE];

void menu();
void invalid();

int main() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);

    puts("Sir, we need a fleet like never seen before. What should we do?");
    int choice, index;

    while(1) {
        menu();
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                printf("Ship index: ");
                scanf("%d", &index);
                if (index < FLEET_SIZE && index >= 0) {
                    fleet[index] = malloc(SHIP_SIZE);
                    puts("Consider it done Capin'.\n");
                } else {invalid();}
                break;

            case 2:
                printf("Ship index: ");
                scanf("%d", &index);
                if (index < FLEET_SIZE && index >= 0 && fleet[index] != NULL) {
                    free(fleet[index]);
                    puts("She's swimmin with the fishes.\n");
                } else {invalid();}
                break;

            case 3:
                printf("Ship index: ");
                scanf("%d", &index);
                if (index < FLEET_SIZE && index >= 0 && fleet[index] != NULL) {
                    printf("Inspection Results: %s\n\n", fleet[index]);
                } else {invalid();}
                break;

            case 4:
                printf("Ship index: ");
                scanf("%d", &index);
                if (index < FLEET_SIZE && index >= 0 && fleet[index] != NULL) {
                    puts("What we need to do Cap?");
                    getchar();
                    read(0, fleet[index], SHIP_SIZE);
                    puts("I will follow your words to a T.\n");
                } else {invalid();}
                break;

            default:
                invalid();
        }
    }
    return 0;
}

void menu() {
    puts("What are your orders sir?");
    puts("1. Commission a Ship");
    puts("2. Scuttle Ship");
    puts("3. Inspect Vessal");
    puts("4. Order Adjustments");
    printf("> ");
}

void invalid() {
    puts("I don't think I can complete those order Captain.");
    exit(1);
}